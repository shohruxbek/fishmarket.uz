<?php
define("DBHOST","localhost");
//define("DBUSER","root");
//define("DBPASS","");
//define("DBNAME","test");
define("DBUSER","milliykr_fishmarket");
define("DBPASS","123dty321*mk");
define("DBNAME","milliykr_fishmarket");
$db = @mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
/*if($db)
{
    echo "\"php\" bazaga ulandi.";
}
else{
    echo "bazada xatolik";
}*/
?>